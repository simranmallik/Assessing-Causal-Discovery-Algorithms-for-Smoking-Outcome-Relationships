Libraries needed

import pandas as pd
import causallearn
from causallearn.search.ConstraintBased.PC import pc
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from causallearn.utils.cit import CIT
from causallearn.graph.Node import Node
from causallearn.graph.Graph import Graph
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from causallearn.utils.GraphUtils import GraphUtils
from tqdm import tqdm
import seaborn as sns
import matplotlib.patches as mpatches

External files needed
	final_df_all_years.csv
Python file
	PC_Full_Smoking_Analysis.ipynb

Causal Inference Kernel Setup
1. Create a new Conda environment with Python 3.10
conda create -n causal-env python=3.10

2. Activate the environment
conda activate causal-env

3. Install required scientific packages
pip install jupyter
pip install numpy scipy scikit-learn networkx

4. Install the CausalLearn library (from GitHub)
pip install git+https://github.com/py-why/causal-learn.git

5. Launch Jupyter Notebook inside this environment 
jupyter notebook

6. Verify installation inside a notebook. In a Jupyter cell, run the code below. If no errors, you're ready to run PC and GES.

import causallearn
from causallearn.search.ConstraintBased.PC import pc


