Libraries needed
  pandas
  numpy
  matplotlib
  seaborn
  missingno
External files needed
  DEMO_F.xpt
  DEMO_G.xpt
  DEMO_H.xpt
  DEMO_I.xpt
  DEMO_J.xpt
  (plus matching BMX, MCQ, and SMQ files for each cycle)
Python file
  NHANES_CDC_Smoking_EDA.py
