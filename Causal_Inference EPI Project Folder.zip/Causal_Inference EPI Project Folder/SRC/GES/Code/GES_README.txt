Libraries needed
	pandas
	numpy
	matplotlib
	seaborn
	networkx
	scikit-learn
	tqdm
	causallearn
External files needed
	final_df_all_years.csv
Python file
	GES_Full_Smoking_Analysis.ipynb
